# THIRD-PARTY SOFTWARE NOTICES AND INFORMATION
Do Not Translate or Localize

# Regression tests for ADOP platform
This project incorporates components from the projects listed below. The original copyright notices and the licenses are set on Licenses file. Accenture reserves all rights not expressly granted herein, whether by implication, estoppel or otherwise.

- java (http://www.oracle.com/technetwork/indexes/downloads/index.html#java)
